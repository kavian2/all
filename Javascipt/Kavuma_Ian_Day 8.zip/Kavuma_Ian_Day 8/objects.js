var  house= {
	Tv:"sony" ,
	shoes:"nike" ,
	shirts:"gucci"	
}
console.log(house.shoes);
function house(sony,nike, gucci){
	this.tv = tv;
	this.shoes= shoes;
	this.shirts=shirts;
}
var student=